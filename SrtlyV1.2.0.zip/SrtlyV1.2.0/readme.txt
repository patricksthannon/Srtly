# Installation Instructions

1. Install Srtly

- Drag `Srtly.app` to your **Applications** folder (or anywhere you like).

2. Install the Quick Action (Allows you to use Srtly by right-clicking folder you wish to sort, then select menu "Quick Actions" -> "Srtly")

- Double-click the `Srtly.workflow` file.
- This will install the Quick Action into your `~/Library/Services` folder.

3. Using the App 

- Launch `Srtly.app` from Applications.

4. Using the Quick Action

- Right-click folder you which to sort, Select menu "Quick Actions" -> "Srtly".

---

If you encounter any permission issues, try opening System Preferences > Security & Privacy > Privacy, and grant necessary access to Files and Folders or Automation.

